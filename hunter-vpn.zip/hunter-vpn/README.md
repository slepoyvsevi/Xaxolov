# 🎯 Хантер VPN — Инструкция по сборке APK

## ⚠️ ВАЖНО о MConverter

MConverter переименовывает ZIP в APK, но **НЕ компилирует** Android-приложение.
Для настоящего APK нужен один из способов ниже.

---

## ✅ Способ 1: PWABuilder (РЕКОМЕНДУЕТСЯ, бесплатно)

1. Залейте папку `hunter-vpn/` на любой хостинг:
   - [Netlify](https://netlify.com) (drag & drop папку → получите URL)
   - [Vercel](https://vercel.com)
   - [GitHub Pages](https://pages.github.com)

2. Зайдите на **https://www.pwabuilder.com**

3. Введите URL вашего сайта → нажмите **Start**

4. Выберите **Android** → **Build Package**

5. Скачайте APK — готово!

---

## ✅ Способ 2: WebIntoApp / AppsGeyser (без кода)

1. Зайдите на **https://websitetoapp.com** или **https://appsgeyser.com**
2. Введите URL сайта или загрузите HTML
3. Скачайте APK напрямую

---

## ✅ Способ 3: Capacitor (для разработчиков)

```bash
npm install -g @capacitor/cli
npm init
npm install @capacitor/core @capacitor/android
npx cap init "Хантер VPN" "com.hunter.vpn"
# Скопируйте файлы приложения в www/
cp hunter-vpn/* www/
npx cap add android
npx cap sync
npx cap open android   # Откроет Android Studio
# В Android Studio: Build → Generate Signed APK
```

---

## 📁 Структура проекта

```
hunter-vpn/
├── index.html      ← Главный интерфейс
├── app.js          ← Логика VPN + WARP API
├── manifest.json   ← PWA манифест
├── icon.png        ← Иконка приложения
├── icon-192.png    ← Иконка 192px
└── icon-512.png    ← Иконка 512px
```

---

## 🔧 Как работает приложение

- **WARP конфиг** генерируется автоматически через Cloudflare API при запуске
- **Регионы** проверяются на пинг в фоне
- **WireGuard** — при установке в WebView вызывает нативный мост `window.HunterVPN.connect(config)`
- **Темы**: синяя / фиолетовая / зелёная + тёмный/светлый режим

---

## 📱 Установка на Android (без Play Store)

1. В настройках Android: **Безопасность → Неизвестные источники** → Включить
2. Скопируйте APK на телефон
3. Нажмите на файл → Установить
